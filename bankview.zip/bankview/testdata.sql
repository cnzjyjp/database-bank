use bank;
insert into 支行
values('浙1', '浙江');
insert into 支行
values('浙2', '浙江');
insert into 支行
values('皖1', '安徽');
insert into 支行
values('皖2', '安徽');

insert into 部门
values('宣传部', '宣传', '1111', '1111', '浙1');
insert into 部门
values('科技部', '科技', '2222', '2222', '浙1');
insert into 部门
values('财务部', '财务', '3333', '3333', '皖1');
insert into 部门
values('科技部', '科技', '4444', '4444', '皖2');
insert into 部门
values('宣传部', '宣传', '5555', '5555', '浙2');
insert into 部门
values('财务部', '科技', '6666', '6666', '浙2');

insert into 员工
values ('1111', '1111', 'test', 'USTC', '8888888', STR_TO_DATE('06/30/2020','%m/%d/%Y'));
insert into 员工
values ('2222', '1111', 'ustc', 'USTC', '8888881', STR_TO_DATE('06/30/2020','%m/%d/%Y'));
insert into 员工
values ('3333', '2222', 'a1', 'USTC', '8888882', STR_TO_DATE('06/30/2020','%m/%d/%Y'));
insert into 员工
values ('4444', '2222', 'a2', 'USTC', '8888883', STR_TO_DATE('06/30/2020','%m/%d/%Y'));
insert into 员工
values ('5555', '4444', 'a3', 'USTC', '8888884', STR_TO_DATE('06/30/2020','%m/%d/%Y'));
insert into 员工
values ('6666', '3333', 'a4', 'USTC', '8888885', STR_TO_DATE('06/30/2020','%m/%d/%Y'));
insert into 员工
values ('7890', '5555', 'a4', 'USTC', '8888886', STR_TO_DATE('06/30/2020','%m/%d/%Y'));

insert into 客户
values('1111', '2222', 'test', 'USTC', '8888888', 'ustc', '8888881', 'ustc@163.com', 'Friends');
insert into 客户
values('2222', '1111', 'ustc', 'USTC', '7777771', 'test', '8888888', 'test@163.com', 'Friends');
insert into 客户
values('5555', '1111', 'a3', 'USTC', '7777771', 'test', '8888888', 'test@163.com', 'Friends');
insert into 客户
values('6666', '3333', 'a4', 'USTC', '7777771', 'a3', '8888888', 'a3@163.com', 'Friends');

insert into 账户
values('111111', '200000',  STR_TO_DATE('06/30/2020','%m/%d/%Y'), STR_TO_DATE('06/30/2020','%m/%d/%Y'));
insert into 账户
values('222222', '300000',  STR_TO_DATE('06/30/2020','%m/%d/%Y'), STR_TO_DATE('06/30/2020','%m/%d/%Y'));
insert into 账户
values('333333', '250000',  STR_TO_DATE('06/30/2020','%m/%d/%Y'), STR_TO_DATE('06/30/2020','%m/%d/%Y'));
insert into 账户
values('444444', '150000',  STR_TO_DATE('06/30/2020','%m/%d/%Y'), STR_TO_DATE('06/30/2020','%m/%d/%Y'));
insert into 账户
values('555555', '350000',  STR_TO_DATE('06/30/2020','%m/%d/%Y'), STR_TO_DATE('06/30/2020','%m/%d/%Y'));

insert into 储蓄账户
values('111111', '200000', STR_TO_DATE('06/30/2020','%m/%d/%Y'), STR_TO_DATE('06/30/2020','%m/%d/%Y'), '0.03', 'RMB');
insert into 储蓄账户
values('333333', '250000', STR_TO_DATE('06/30/2020','%m/%d/%Y'), STR_TO_DATE('06/30/2020','%m/%d/%Y'), '0.04', 'Dollar');
insert into 储蓄账户
values('444444', '150000', STR_TO_DATE('06/30/2020','%m/%d/%Y'), STR_TO_DATE('06/30/2020','%m/%d/%Y'), '0.05', 'RMB');
insert into 支票账户
values('222222', '300000', STR_TO_DATE('05/30/2020','%m/%d/%Y'), STR_TO_DATE('06/30/2020','%m/%d/%Y'),'30000');
insert into 支票账户
values('555555', '350000', STR_TO_DATE('04/30/2020','%m/%d/%Y'), STR_TO_DATE('06/30/2020','%m/%d/%Y'), '10000');

insert into 开户
values('1111', '111111', '浙1', 'Saving');
insert into 开户
values('2222', '333333', '浙1', 'Saving');
insert into 开户
values('5555', '444444', '皖1', 'Saving');
insert into 开户
values('1111', '222222', '浙2', 'Credit');
insert into 开户
values('6666', '555555', '皖2', 'Credit');

insert into 贷款
values('1111', '浙1', 300000, 6);
insert into 贷款
values('2222', '浙2', 400000, 8);
insert into 贷款
values('5555', '皖1', 900000, 10);
insert into 贷款
values('6666', '皖2', 400000, 2);

insert into 支付
values(1, '6666', '1111', 200000);
insert into 支付
values(2, '6666', '1111', 200000);
insert into 支付
values(1, '1111', '2222', 80000);
insert into 支付
values(1, '2222', '5555', 20000);
insert into 支付
values(2, '2222', '5555', 100000);