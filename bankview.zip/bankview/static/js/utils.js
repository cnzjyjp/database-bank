$(document).ready(function(){
    $('.body').height($(window).height());
})