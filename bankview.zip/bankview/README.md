## README

##### 环境配置

Mysql, NodeJs

##### 启动方法

在本目录下：

执行`init.sql`生成数据库；

执行`testdate.sql`导入测试数据；

在`config.js`中将数据库账号密码改为你的计算机上Mysql数据库的账号密码；

在cmd中执行 npm install;

在cmd中执行npm start；

在浏览器中访问 127.0.0.1:3000 ，建议使用Chrome。

##### 登入

账号：root

密码：password

**Tips**

增删改查时，在输入列中要填写的内容按文本框上方提示为准，可以参照数据库格式（文本框预先显示的内容请无视，为了省时间复用搞乱了）。